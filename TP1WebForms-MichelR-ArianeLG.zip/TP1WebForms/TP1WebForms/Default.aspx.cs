﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Diagnostics;

namespace TP1WebForms
{
    public partial class Default : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //GridViewActivités.DataSource = Activité.getDetails();
            //GridViewActivités.DataBind();
        }
    }
}